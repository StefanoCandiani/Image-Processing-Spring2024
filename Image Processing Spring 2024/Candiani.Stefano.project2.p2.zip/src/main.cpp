#include <iostream>
#include <fstream>
#include <vector>
#include "File.h"
using namespace std;

int main() {
    Photoshop practice;

/// Multiply test (Part1)

    fstream readFileP1_1("./input/layer1.tga", ios_base::binary | ios_base::in);
    fstream readFileP1_2("./input/pattern1.tga", ios_base::binary | ios_base::in);
    fstream copyFileP1("./output/part1.tga", ios_base::binary | ios_base::out);

    Header layer1HeaderP1 = practice.storeHeader(readFileP1_1);
    Header pattern1HeaderP1 = practice.storeHeader(readFileP1_2);

    vector<vector<unsigned char>> layer1PixelsP1;
    vector<vector<unsigned char>> pattern1PixelsP1;
    vector<vector<unsigned char>> finalPixelsP1;

    practice.storeData(readFileP1_1, layer1HeaderP1, layer1PixelsP1);
    practice.storeData(readFileP1_2, pattern1HeaderP1, pattern1PixelsP1);

    for(int i = 0; i < layer1PixelsP1.size(); i++) {
        finalPixelsP1.push_back(practice.multiply(layer1PixelsP1.at(i), pattern1PixelsP1.at(i)));
    }

    practice.writeFile(copyFileP1,layer1HeaderP1,finalPixelsP1);

    readFileP1_1.close();   readFileP1_2.close();   copyFileP1.close();

/// Subtract test (Part2)

    fstream readFileP2_1("./input/car.tga", ios_base::binary | ios_base::in);
    fstream readFileP2_2("./input/layer2.tga", ios_base::binary | ios_base::in);
    fstream copyFileP2("./output/part2.tga", ios_base::binary | ios_base::out);

    Header layer1HeaderP2 = practice.storeHeader(readFileP2_1);
    Header pattern1HeaderP2 = practice.storeHeader(readFileP2_2);

    vector<vector<unsigned char>> layer1PixelsP2;
    vector<vector<unsigned char>> pattern1PixelsP2;
    vector<vector<unsigned char>> finalPixelsP2;

    practice.storeData(readFileP2_1, layer1HeaderP2, layer1PixelsP2);
    practice.storeData(readFileP2_2, pattern1HeaderP2, pattern1PixelsP2);

    for(int i = 0; i < layer1PixelsP2.size(); i++) {
        finalPixelsP2.push_back(practice.subtract(layer1PixelsP2.at(i), pattern1PixelsP2.at(i)));
    }

    practice.writeFile(copyFileP2,layer1HeaderP2,finalPixelsP2);

    readFileP2_1.close();   readFileP2_2.close();   copyFileP2.close();

/// Multiply and Screen test (Part3)

    fstream readFileP3_1("./input/layer1.tga", ios_base::binary | ios_base::in);
    fstream readFileP3_2("./input/pattern2.tga", ios_base::binary | ios_base::in);
    fstream readFileP3_3("./input/text.tga", ios_base::binary | ios_base::in);
    fstream copyFileP3("./output/part3.tga", ios_base::binary | ios_base::out);

    Header layer1HeaderP3 = practice.storeHeader(readFileP3_1);
    Header pattern1HeaderP3 = practice.storeHeader(readFileP3_2);
    Header pattern2HeaderP3 = practice.storeHeader(readFileP3_3);

    vector<vector<unsigned char>> layer1PixelsP3;
    vector<vector<unsigned char>> pattern1PixelsP3;
    vector<vector<unsigned char>> pattern2PixelsP3;
    vector<vector<unsigned char>> finalPixelsP3;

    practice.storeData(readFileP3_1, layer1HeaderP3, layer1PixelsP3);
    practice.storeData(readFileP3_2, pattern1HeaderP3, pattern1PixelsP3);
    practice.storeData(readFileP3_3, pattern2HeaderP3, pattern2PixelsP3);


    for(int i = 0; i < layer1PixelsP3.size(); i++){
        finalPixelsP3.push_back(practice.multiply(layer1PixelsP3.at(i), pattern1PixelsP3.at(i)));
        finalPixelsP3.at(i) = practice.screen(finalPixelsP3.at(i), pattern2PixelsP3.at(i));
    }

    practice.writeFile(copyFileP3,layer1HeaderP3,finalPixelsP3);

    readFileP3_1.close();   readFileP3_2.close();   readFileP3_3.close();   copyFileP3.close();

/// Multiply and subtract test (Part4)

    fstream readFileP4_1("./input/layer2.tga", ios_base::binary | ios_base::in);
    fstream readFileP4_2("./input/circles.tga", ios_base::binary | ios_base::in);
    fstream readFileP4_3("./input/pattern2.tga", ios_base::binary | ios_base::in);
    fstream copyFileP4("./output/part4.tga", ios_base::binary | ios_base::out);

    Header layer1HeaderP4 = practice.storeHeader(readFileP4_1);
    Header pattern1HeaderP4 = practice.storeHeader(readFileP4_2);
    Header pattern2HeaderP4 = practice.storeHeader(readFileP4_3);

    vector<vector<unsigned char>> layer1PixelsP4;
    vector<vector<unsigned char>> pattern1PixelsP4;
    vector<vector<unsigned char>> pattern2PixelsP4;
    vector<vector<unsigned char>> finalPixelsP4;

    practice.storeData(readFileP4_1, layer1HeaderP4, layer1PixelsP4);
    practice.storeData(readFileP4_2, pattern1HeaderP4, pattern1PixelsP4);
    practice.storeData(readFileP4_3, pattern2HeaderP4, pattern2PixelsP4);

    for(int i = 0; i < layer1PixelsP4.size(); i++) {
        finalPixelsP4.push_back(practice.multiply(layer1PixelsP4.at(i), pattern1PixelsP4.at(i)));
        finalPixelsP4.at(i) = practice.subtract(finalPixelsP4.at(i), pattern2PixelsP4.at(i));
    }

    practice.writeFile(copyFileP4,layer1HeaderP4,finalPixelsP4);

    readFileP4_1.close();   readFileP4_2.close();   readFileP4_3.close();   copyFileP4.close();

/// Overlay test (Part5)

    fstream readFileP5_1("./input/layer1.tga", ios_base::binary | ios_base::in);
    fstream readFileP5_2("./input/pattern1.tga", ios_base::binary | ios_base::in);
    fstream copyFileP5("./output/part5.tga", ios_base::binary | ios_base::out);

    Header layer1HeaderP5 = practice.storeHeader(readFileP5_1);
    Header pattern1HeaderP5 = practice.storeHeader(readFileP5_2);

    vector<vector<unsigned char>> layer1PixelsP5;
    vector<vector<unsigned char>> pattern1PixelsP5;
    vector<vector<unsigned char>> finalPixelsP5;

    practice.storeData(readFileP5_1, layer1HeaderP5, layer1PixelsP5);
    practice.storeData(readFileP5_2, pattern1HeaderP5, pattern1PixelsP5);


    for(int i = 0; i < layer1PixelsP5.size(); i++) {
        finalPixelsP5.push_back(practice.overlay(layer1PixelsP5.at(i), pattern1PixelsP5.at(i)));
    }

    practice.writeFile(copyFileP5,layer1HeaderP5,finalPixelsP5);

    readFileP5_1.close();   readFileP5_2.close();   copyFileP5.close();

/// Add green test (Part6)

    fstream readFileP6_1("./input/car.tga", ios_base::binary | ios_base::in);
    fstream copyFileP6("./output/part6.tga", ios_base::binary | ios_base::out);

    Header layer1HeaderP6 = practice.storeHeader(readFileP6_1);

    vector<vector<unsigned char>> layer1PixelsP6;
    vector<vector<unsigned char>> finalPixelsP6;

    practice.storeData(readFileP6_1, layer1HeaderP6, layer1PixelsP6);

    for(int i = 0; i < layer1PixelsP6.size(); i++) {
        finalPixelsP6.push_back(practice.add(layer1PixelsP6.at(i), {0, 200, 0}));
    }

    practice.writeFile(copyFileP6,layer1HeaderP6,finalPixelsP6);

    readFileP6_1.close();   copyFileP6.close();

/// Multiply red by 4 and blue by 0 (Part7)

    fstream readFileP7_1("./input/car.tga", ios_base::binary | ios_base::in);
    fstream copyFileP7("./output/part7.tga", ios_base::binary | ios_base::out);

    Header layer1HeaderP7 = practice.storeHeader(readFileP7_1);

    vector<vector<unsigned char>> layer1PixelsP7;
    vector<vector<unsigned char>> finalPixelsP7;

    practice.storeData(readFileP7_1, layer1HeaderP7, layer1PixelsP7);

    for(int i = 0; i < layer1PixelsP7.size(); i++) {
        finalPixelsP7.push_back(practice.scale(layer1PixelsP7.at(i), {0,1,4}));
    }

    practice.writeFile(copyFileP7,layer1HeaderP7,finalPixelsP7);

    readFileP7_1.close();   copyFileP7.close();

/// Separating channels (Part8)

    fstream readFileP8_1("./input/car.tga", ios_base::binary | ios_base::in);
    fstream copyFileP8_b("./output/part8_b.tga", ios_base::binary | ios_base::out);
    fstream copyFileP8_g("./output/part8_g.tga", ios_base::binary | ios_base::out);
    fstream copyFileP8_r("./output/part8_r.tga", ios_base::binary | ios_base::out);

    Header layer1HeaderP8 = practice.storeHeader(readFileP8_1);

    vector<vector<unsigned char>> layer1PixelsP8;
    vector<vector<unsigned char>> finalPixelsP8_b;
    vector<vector<unsigned char>> finalPixelsP8_g;
    vector<vector<unsigned char>> finalPixelsP8_r;


    practice.storeData(readFileP8_1, layer1HeaderP8, layer1PixelsP8);

/// Blue
    for(int i = 0; i < layer1PixelsP8.size(); i++) {
        finalPixelsP8_b.push_back({layer1PixelsP8.at(i).at(0),layer1PixelsP8.at(i).at(0),layer1PixelsP8.at(i).at(0)});
    }

/// Green
    for(int i = 0; i < layer1PixelsP8.size(); i++) {
        finalPixelsP8_g.push_back({layer1PixelsP8.at(i).at(1),layer1PixelsP8.at(i).at(1),layer1PixelsP8.at(i).at(1)});
    }

/// Red
    for(int i = 0; i < layer1PixelsP8.size(); i++) {
        finalPixelsP8_r.push_back({layer1PixelsP8.at(i).at(2),layer1PixelsP8.at(i).at(2),layer1PixelsP8.at(i).at(2)});
    }

    practice.writeFile(copyFileP8_b, layer1HeaderP8, finalPixelsP8_b);
    practice.writeFile(copyFileP8_g, layer1HeaderP8, finalPixelsP8_g);
    practice.writeFile(copyFileP8_r, layer1HeaderP8, finalPixelsP8_r);

    readFileP8_1.close();   copyFileP8_b.close();   copyFileP8_g.close();   copyFileP8_r.close();


/// Combining channels (Part9)

    fstream layer1P9 ("./input/layer_blue.tga", ios_base::binary | ios_base::in);
    fstream layer2P9 ("./input/layer_green.tga", ios_base::binary | ios_base::in);
    fstream layer3P9 ("./input/layer_red.tga", ios_base::binary | ios_base::in);
    fstream copyFileP9 ("./output/part9.tga", ios_base::binary | ios_base::out);

    vector<vector<unsigned char>> layer1PixelsP9;
    vector<vector<unsigned char>> layer2PixelsP9;
    vector<vector<unsigned char>> layer3PixelsP9;
    vector<vector<unsigned char>> finalPixelsP9;

    Header layer1HeaderP9 = practice.storeHeader(layer1P9);
    Header layer2HeaderP9 = practice.storeHeader(layer2P9);
    Header layer3HeaderP9 = practice.storeHeader(layer3P9);

    practice.storeData(layer1P9,layer1HeaderP9,layer1PixelsP9);
    practice.storeData(layer2P9,layer2HeaderP9,layer2PixelsP9);
    practice.storeData(layer3P9,layer3HeaderP9,layer3PixelsP9);

    for(int i = 0; i < layer1PixelsP9.size(); i++) {
        finalPixelsP9.push_back({layer1PixelsP9.at(i).at(0), layer2PixelsP9.at(i).at(1), layer3PixelsP9.at(i).at(2)});
    }

    practice.writeFile(copyFileP9,layer1HeaderP9,finalPixelsP9);

    layer1P9.close();   layer2P9.close();   layer3P9.close();   copyFileP9.close();

/// Rotating image (Part10)

    fstream layer1P10 ("./input/text2.tga", ios_base::binary | ios_base::in);
    fstream copyFileP10 ("./output/part10.tga", ios_base::binary | ios_base::out);

    vector<vector<unsigned char>> layer1PixelsP10;
    vector<vector<unsigned char>> finalPixelsP10;

    Header layer1HeaderP10 = practice.storeHeader(layer1P10);

    practice.storeData(layer1P10,layer1HeaderP10,layer1PixelsP10);
    finalPixelsP10.resize(layer1PixelsP10.size());

    int counter = layer1PixelsP10.size() - 1;
    for(int i = 0; i < layer1PixelsP10.size(); i++) {
        finalPixelsP10.at(counter) = layer1PixelsP10.at(i);
        counter--;
    }

    practice.writeFile(copyFileP10,layer1HeaderP10,finalPixelsP10);

    layer1P10.close();   copyFileP10.close();

    return 0;
}
